package com.example.nancalculator

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // UI Widgets
    private lateinit var countrySpinner: Spinner
    private lateinit var centuryInput: EditText
    private lateinit var searchButton: Button
    private lateinit var resultsText: TextView

    // Music Player
    private lateinit var mediaPlayer: MediaPlayer

    // Playlist
    private val songs = listOf(
        R.raw.marchmusic1
    )

    // Current Song Index
    private var currentSongIndex = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Connect XML widgets
        countrySpinner = findViewById(R.id.countrySpinner)
        centuryInput = findViewById(R.id.centuryInput)
        searchButton = findViewById(R.id.searchButton)
        resultsText = findViewById(R.id.resultsText)

        // Instructions
        val openButton = findViewById<Button>(R.id.instruButton)

        openButton.setOnClickListener {
            val intent = Intent(this, InstructionsActivity::class.java)
            startActivity(intent)
        }

        // Spinner countries
        val countries = arrayOf(
            "England",
            "France",
            "Germany",
            "Japan",
            "United States",
            "Russia",
            "China",
            "Turkey",
            "Spain",
            "Italy",
            "Greece",
            "Iran",
            "India",
            "Pakistan",
            "Korea",
            "Vietnam",
            "Mongolia",
            "Sweden",
            "Poland",
            "Ukraine"
        )

        // Spinner adapter
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            countries
        )

        countrySpinner.adapter = adapter

        // Start background music playlist
        playSong(currentSongIndex)

        // Conflict database
        val conflicts = listOf(

            // ENGLAND
            Conflict("England", 11, "Norman Conquest"),
            Conflict("England", 13, "Barons' War"),
            Conflict("England", 15, "Wars of the Roses"),
            Conflict("England", 17, "English Civil War"),
            Conflict("England", 18, "American Revolutionary War"),
            Conflict("England", 19, "Napoleonic Wars"),
            Conflict("England", 20, "World War I"),
            Conflict("England", 20, "World War II"),

            // FRANCE
            Conflict("France", 14, "Hundred Years' War"),
            Conflict("France", 16, "French Wars of Religion"),
            Conflict("France", 18, "French Revolutionary Wars"),
            Conflict("France", 19, "Napoleonic Wars"),
            Conflict("France", 19, "Franco-Prussian War"),
            Conflict("France", 20, "World War I"),
            Conflict("France", 20, "World War II"),
            Conflict("France", 20, "First Indochina War"),

            // GERMANY
            Conflict("Germany", 17, "Thirty Years' War"),
            Conflict("Germany", 19, "Franco-Prussian War"),
            Conflict("Germany", 20, "World War I"),
            Conflict("Germany", 20, "World War II"),
            Conflict("Germany", 20, "Cold War"),

            // JAPAN
            Conflict("Japan", 12, "Genpei War"),
            Conflict("Japan", 16, "Sengoku Period Conflicts"),
            Conflict("Japan", 19, "Boshin War"),
            Conflict("Japan", 20, "Russo-Japanese War"),
            Conflict("Japan", 20, "Second Sino-Japanese War"),
            Conflict("Japan", 20, "World War II"),

            // UNITED STATES
            Conflict("United States", 18, "American Revolutionary War"),
            Conflict("United States", 19, "War of 1812"),
            Conflict("United States", 19, "Mexican-American War"),
            Conflict("United States", 19, "American Civil War"),
            Conflict("United States", 20, "World War I"),
            Conflict("United States", 20, "World War II"),
            Conflict("United States", 20, "Korean War"),
            Conflict("United States", 20, "Vietnam War"),
            Conflict("United States", 21, "War in Afghanistan"),
            Conflict("United States", 21, "Iraq War"),

            // RUSSIA
            Conflict("Russia", 13, "Mongol Invasion of Rus"),
            Conflict("Russia", 19, "Crimean War"),
            Conflict("Russia", 20, "Russo-Japanese War"),
            Conflict("Russia", 20, "Russian Civil War"),
            Conflict("Russia", 20, "World War II"),
            Conflict("Russia", 20, "Cold War"),
            Conflict("Russia", 21, "Russo-Ukrainian War"),

            // CHINA
            Conflict("China", 13, "Mongol Conquest of China"),
            Conflict("China", 19, "Opium Wars"),
            Conflict("China", 19, "Taiping Rebellion"),
            Conflict("China", 20, "Chinese Civil War"),
            Conflict("China", 20, "Second Sino-Japanese War"),
            Conflict("China", 20, "Korean War"),

            // TURKEY
            Conflict("Turkey", 15, "Fall of Constantinople"),
            Conflict("Turkey", 16, "Ottoman-Safavid Wars"),
            Conflict("Turkey", 19, "Crimean War"),
            Conflict("Turkey", 20, "World War I"),
            Conflict("Turkey", 20, "Turkish War of Independence"),

            // SPAIN
            Conflict("Spain", 15, "Granada War"),
            Conflict("Spain", 16, "Italian Wars"),
            Conflict("Spain", 19, "Peninsular War"),
            Conflict("Spain", 20, "Spanish Civil War"),

            // ITALY
            Conflict("Italy", 16, "Italian Wars"),
            Conflict("Italy", 19, "Italian Wars of Independence"),
            Conflict("Italy", 20, "World War I"),
            Conflict("Italy", 20, "World War II"),

            // GREECE
            Conflict("Greece", 19, "Greek War of Independence"),
            Conflict("Greece", 20, "Greco-Turkish War"),
            Conflict("Greece", 20, "World War II"),

            // IRAN
            Conflict("Iran", 16, "Ottoman-Safavid Wars"),
            Conflict("Iran", 20, "Iran-Iraq War"),

            // INDIA
            Conflict("India", 18, "Anglo-Mysore Wars"),
            Conflict("India", 19, "Indian Rebellion of 1857"),
            Conflict("India", 20, "Indo-Pakistani War of 1947"),
            Conflict("India", 20, "Indo-Pakistani War of 1971"),

            // PAKISTAN
            Conflict("Pakistan", 20, "Indo-Pakistani War of 1947"),
            Conflict("Pakistan", 20, "Indo-Pakistani War of 1971"),

            // KOREA
            Conflict("Korea", 16, "Imjin War"),
            Conflict("Korea", 20, "Korean War"),

            // VIETNAM
            Conflict("Vietnam", 20, "First Indochina War"),
            Conflict("Vietnam", 20, "Vietnam War"),

            // MONGOLIA
            Conflict("Mongolia", 13, "Mongol Invasions"),

            // SWEDEN
            Conflict("Sweden", 17, "Thirty Years' War"),
            Conflict("Sweden", 18, "Great Northern War"),

            // POLAND
            Conflict("Poland", 17, "Deluge"),
            Conflict("Poland", 20, "World War II"),

            // UKRAINE
            Conflict("Ukraine", 21, "Russo-Ukrainian War")
        )

        // Search button logic
        searchButton.setOnClickListener {

            val selectedCountry =
                countrySpinner.selectedItem.toString()

            val centuryText =
                centuryInput.text.toString()

            // Empty input check
            if (centuryText.isEmpty()) {

                resultsText.text =
                    "RESULTS: Please enter a century."

                return@setOnClickListener
            }

            val century = centuryText.toInt()

            // Filter conflicts
            val filteredConflicts = conflicts.filter {

                it.country == selectedCountry &&
                        it.century == century
            }

            // Show results
            if (filteredConflicts.isEmpty()) {

                resultsText.text =
                    "RESULTS: No conflicts found for $selectedCountry in the ${century}th century."

            } else {

                val resultString =
                    filteredConflicts.joinToString("\n\n") {

                        "• ${it.name}"
                    }

                resultsText.text =
                    "RESULTS:\n\n$resultString"
            }
        }
    }

    // Music Playlist Function
    private fun playSong(index: Int) {

        mediaPlayer = MediaPlayer.create(this, songs[index])

        mediaPlayer.start()

        mediaPlayer.setOnCompletionListener {

            mediaPlayer.release()

            currentSongIndex++

            if (currentSongIndex >= songs.size) {
                currentSongIndex = 0
            }

            playSong(currentSongIndex)
        }
    }

    // Pause music when app minimized
    override fun onPause() {
        super.onPause()

        if (::mediaPlayer.isInitialized) {
            mediaPlayer.pause()
        }
    }

    // Resume music when app reopened
    override fun onResume() {
        super.onResume()

        if (::mediaPlayer.isInitialized) {
            mediaPlayer.start()
        }
    }

    // Release memory
    override fun onDestroy() {
        super.onDestroy()

        if (::mediaPlayer.isInitialized) {
            mediaPlayer.release()
        }
    }
}

private fun InstructionsActivity.dismiss() {
    TODO("Not yet implemented")
}

private fun InstructionsActivity.showAtLocation(popupView: View) {}
