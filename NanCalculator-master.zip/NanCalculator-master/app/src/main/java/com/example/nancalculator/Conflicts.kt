package com.example.nancalculator

data class Conflict(
    val country: String,
    val century: Int,
    val name: String
)